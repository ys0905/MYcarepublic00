"""Google Calendar (local desktop OAuth) and Gemini extraction adapters."""
from __future__ import annotations
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
import json
import os
import re

ROOT = Path(__file__).resolve().parent
SCOPES = ['https://www.googleapis.com/auth/calendar.readonly']
CATEGORIES = ('caution','preference','rapport','visit')
PRIORITIES = ('HIGH','MEDIUM','LOW','UNKNOWN')


def credentials_status():
    return (ROOT/'credentials.json').exists(), (ROOT/'token.json').exists()


def google_events(days_before=14,days_after=65):
    """Local-machine OAuth; user explicitly clicks connect/sync. Not cloud deployment OAuth."""
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build

    secret=ROOT/'credentials.json'
    token=ROOT/'token.json'
    if not secret.exists():
        raise FileNotFoundError('credentials.json을 프로그램 폴더에 넣어 주세요.')
    payload=json.loads(secret.read_text(encoding='utf-8'))
    if 'installed' not in payload:
        raise ValueError('Google OAuth 클라이언트 유형을 데스크톱 앱으로 발급해 주세요.')
    creds=Credentials.from_authorized_user_file(str(token),SCOPES) if token.exists() else None
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            creds=InstalledAppFlow.from_client_secrets_file(str(secret),SCOPES).run_local_server(port=0, open_browser=True)
        token.write_text(creds.to_json(),encoding='utf-8')
        try: os.chmod(token,0o600)
        except OSError: pass
    api=build('calendar','v3',credentials=creds,cache_discovery=False)
    start=datetime.now(timezone.utc) - timedelta(days=days_before)
    end=datetime.now(timezone.utc) + timedelta(days=days_after)
    rows=[]; page=None
    while True:
        result=api.events().list(calendarId='primary',timeMin=start.isoformat(),
            timeMax=end.isoformat(),maxResults=250,singleEvents=True,orderBy='startTime',pageToken=page).execute()
        rows.extend(result.get('items',[]))
        page=result.get('nextPageToken')
        if not page: break
    return rows


# Small, conservative JSON output; use evidence quotes that appear in the memo.
FACT_SCHEMA={
    'type':'object', 'properties': {
        'items': {'type':'array','items': {'type':'object','properties': {
            'category':{'type':'string','enum':list(CATEGORIES)},
            'statement':{'type':'string'},
            'priority':{'type':'string','enum':list(PRIORITIES)},
            'evidence':{'type':'string'},
            'source_type':{'type':'string','enum':['customer_report','owner_observation','unclear']}
        },'required':['category','statement','priority','evidence','source_type']}}
    },'required':['items']
}

SYSTEM_RULES='''너는 뷰티샵 원장의 짧은 업무 메모에서 사실만 정리하는 데이터 추출 도우미다.
- 서비스는 네일/피부/속눈썹/왁싱/두피 등 업종 공통이다.
- 오직 입력된 기록을 근거로 항목별로 분리한다. 기록에 없는 사실, 의학적 진단, 알레르기 확진, 시술 권고를 창작하지 말 것.
- category: caution=시술 전 확인사항, preference=취향, rapport=대화 키워드, visit=방문/시술 이력.
- priority: HIGH=과거 이상 반응/알레르기 언급처럼 먼저 확인할 이력, MEDIUM=민감도·불편 경험, LOW=일반 참고, UNKNOWN=의미 불명확.
- 위험도는 건강상 위험 판정이 아닌 기록 확인 우선순위다.
- 직접 말한 경험/증상은 '경험했다고 함, 원인 미확인'으로 표현할 것.
- source_type: customer_report(고객이 말했다고 기록됨), owner_observation(원장이 직접 관찰), unclear(확인 불명).
- evidence는 입력 메모에 실제로 연속해서 나타나는 짧은 원문 구절이어야 한다.
- 이전 일정은 미래라고 단정하지 말 것. 민감한 사생활 대화 추천은 하지 말 것.
- 최대 12개 사실만 뽑고, 분명한 정보가 없다면 빈 목록을 돌려라.
'''


def _clean(text):
    return re.sub(r'\s+','',text)


def validate_items(items,memo):
    filtered=[]; seen=set()
    for item in (items if isinstance(items,list) else []):
        if not isinstance(item,dict): continue
        category=item.get('category'); priority=item.get('priority','UNKNOWN')
        statement=str(item.get('statement') or '').strip()[:250]
        evidence=str(item.get('evidence') or '').strip()[:160]
        source=item.get('source_type','unclear')
        if category not in CATEGORIES or not statement or not evidence: continue
        # Skip AI output that cannot be traced to input. User may override via review UI.
        if _clean(evidence) not in _clean(memo): continue
        key=(category,statement)
        if key in seen: continue
        seen.add(key)
        filtered.append(dict(category=category, priority=priority if priority in PRIORITIES else 'UNKNOWN',
            statement=statement,evidence=evidence,
            source_type=source if source in ('customer_report','owner_observation','unclear') else 'unclear'))
    return filtered[:12]


def analyze_with_gemini(memo,service=''):
    from google import genai
    key=os.environ.get('GEMINI_API_KEY','').strip()
    if not key: raise ValueError('GEMINI_API_KEY가 설정되지 않았습니다.')
    client=genai.Client(api_key=key)
    response=client.models.generate_content(
        model=os.getenv('GEMINI_MODEL','gemini-2.5-flash'),
        contents=SYSTEM_RULES+f'\n업종/시술: {service or "미지정"}\n원장 메모: <<<\n{memo}\n>>>',
        config={'response_mime_type':'application/json', 'response_json_schema':FACT_SCHEMA,'temperature':0.1},
    )
    if response.parsed is not None:
        result=response.parsed
        if hasattr(result,'model_dump'):result=result.model_dump()
    else:result=json.loads(response.text or '{}')
    if not isinstance(result,dict): raise ValueError('분석 응답 형식이 올바르지 않습니다.')
    return validate_items(result.get('items',[]),memo)


def local_demo_extract(memo,service=''):
    """Clearly labeled local keyword rules, NOT AI. Usable without any API key."""
    text=memo.strip()
    chunks=[s.strip() for s in re.split(r'[\n.!?。]+',text) if s.strip()]
    caution=['알레르기','붉어','가려','따끔','아프','아픔','자극','예민','민감','트러블','열감','따가','화끈','불편','아토피']
    preference=['선호','좋아','원함','원하','싫어','스타일','디자인','색상','길이','자연스러운','심플','취향','비선호','짧은','진한']
    rapport=['여행','면접','결혼','생일','취미','운동','학교','직장','이직','반려','출국','휴가']
    visit=['진행','시술','관리 받','케어','방문','만족','제거','연장','마사지']
    result=[]
    for seg in chunks:
        if len(result)>=12:break
        if any(x in seg for x in caution):
            priority='HIGH' if any(x in seg for x in ['알레르기','붉어','가려','따끔','트러블','화끈']) else 'MEDIUM'
            cat='caution'
        elif any(x in seg for x in preference): cat='preference';priority='LOW'
        elif any(x in seg for x in rapport): cat='rapport';priority='LOW'
        elif any(x in seg for x in visit): cat='visit';priority='LOW'
        else:continue
        result.append(dict(category=cat,statement=seg,priority=priority,evidence=seg,source_type='unclear'))
    return result
