import os,sys,tempfile,unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import db,services

class TestStore(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();os.environ['MOA_DB_PATH']=str(Path(self.temp.name)/'test.db')
        db.init_db()
    def tearDown(self):self.temp.cleanup();os.environ.pop('MOA_DB_PATH',None)
    def test_lifecycle(self):
        cid=db.add_customer('김민지','', '네일')
        db.add_reservation('김민지 네일 예약','2026-11-04T12:00',cid,'네일')
        nid=db.add_note_with_facts(cid,'손톱 주변이 가려웠다고 함','네일','2026-11-03',[
            dict(category='caution',statement='가려움 경험, 원인 미확인',priority='HIGH',evidence='가려웠다고 함')])
        self.assertEqual(len(db.facts_for(cid)),1)
        db.edit_fact(db.facts_for(cid)[0]['id'],'시술 후 가려움','caution','MEDIUM')
        self.assertEqual(db.facts_for(cid)[0]['priority'],'MEDIUM')
        db.edit_note(nid,'가려움 경험이 있었다고 기록','네일','2026-11-03')
        self.assertEqual(db.facts_for(cid),[])
        db.delete_customer(cid)
        self.assertEqual(db.notes_for(cid),[])
        self.assertIsNone(db.reservation(db.all_reservations('2026-11-04','2026-11-05')[0]['id'])['customer_id'])
    def test_calendar_upsert_no_duplicate(self):
        e={'id':'event123','summary':'김민지 네일','start':{'dateTime':'2026-11-04T10:00:00+09:00'}}
        db.upsert_google_events([e]);db.upsert_google_events([e])
        self.assertEqual(len(db.all_reservations('2026-11-04','2026-11-05')),1)
    def test_validate_ai_does_not_add_fake_evidence(self):
        memo='베이지색 좋아함.'
        items=[{'category':'preference','statement':'베이지색 선호','priority':'LOW','evidence':'베이지색 좋아함'},
               {'category':'caution','statement':'알레르기 있음','priority':'HIGH','evidence':'알레르기가 있다'}]
        self.assertEqual(len(services.validate_items(items,memo)),1)
    def test_demo_does_not_reappear_after_deletion(self):
        self.assertTrue(db.seed_demo())
        self.assertEqual(len(db.all_customers()),10)
        for c in db.all_customers():db.delete_customer(c['id'])
        self.assertFalse(db.seed_demo())
        self.assertEqual(len(db.all_customers()),0)
    def test_fact_reanalysis_replaces_existing_values(self):
        cid=db.add_customer('테스트 고객')
        nid=db.add_note_with_facts(cid,'베이지색 선호','네일','2026-11-03',[])
        db.replace_note_facts(nid,[dict(category='preference',statement='베이지색 선호',priority='LOW')])
        self.assertEqual(len(db.facts_for(cid)),1)
        db.replace_note_facts(nid,[dict(category='caution',statement='확인 필요한 정보',priority='UNKNOWN')])
        self.assertEqual(len(db.facts_for(cid)),1)
        self.assertEqual(db.facts_for(cid)[0]['category'],'caution')
    def test_demo_mode_is_local(self):
        result=services.local_demo_extract('지난번에 가려웠다고 함. 베이지색 선호. 여행 예정')
        cats={x['category'] for x in result}
        self.assertTrue({'caution','preference','rapport'}.issubset(cats))

if __name__=='__main__':unittest.main()
