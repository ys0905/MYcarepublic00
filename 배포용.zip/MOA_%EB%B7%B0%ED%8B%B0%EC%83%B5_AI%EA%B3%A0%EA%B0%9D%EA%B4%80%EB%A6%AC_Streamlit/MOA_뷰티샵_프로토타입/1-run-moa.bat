@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo [MOA] Streamlit server will open the browser after startup.
echo URL: http://localhost:8501
where py >nul 2>&1
if %errorlevel% equ 0 (
  py -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501
) else (
  python -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501
)
echo.
echo The server stopped or an error occurred. Read the error above.
pause
