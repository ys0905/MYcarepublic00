import os
import tempfile
import unittest
from pathlib import Path
import services

class TestSettings(unittest.TestCase):
    def test_save_clear_key(self):
        original=services.ROOT
        old_env={k:os.environ.get(k) for k in ('GEMINI_API_KEY','GEMINI_MODEL')}
        with tempfile.TemporaryDirectory() as tmp:
            try:
                services.ROOT=Path(tmp)
                services.save_gemini_settings('test-example-123','gemini-2.5-flash')
                self.assertEqual(os.environ['GEMINI_API_KEY'],'test-example-123')
                self.assertIn('GEMINI_API_KEY=test-example-123',(Path(tmp)/'.env').read_text())
                services.clear_gemini_settings()
                self.assertNotIn('GEMINI_API_KEY',os.environ)
                self.assertNotIn('GEMINI_API_KEY=test-example-123',(Path(tmp)/'.env').read_text())
            finally:
                services.ROOT=original
                for k,v in old_env.items():
                    if v is None:os.environ.pop(k,None)
                    else:os.environ[k]=v
    def test_bad_key_newlines_rejected(self):
        with self.assertRaises(ValueError):
            services.save_gemini_settings('fake\nINJECT=1')
    def test_login_unset_by_default(self):
        old=services.ROOT
        with tempfile.TemporaryDirectory() as tmp:
            try:
                services.ROOT=Path(tmp)
                self.assertFalse(services.google_login_configured())
            finally:services.ROOT=old

if __name__=='__main__':unittest.main()
