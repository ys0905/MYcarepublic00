import os
import unittest
import tempfile
from pathlib import Path
import db

class TestEmptyDB(unittest.TestCase):
    def test_first_launch_has_no_fake_customers(self):
        old=os.environ.get('MYCARE_DB_PATH')
        with tempfile.TemporaryDirectory() as td:
            try:
                os.environ['MYCARE_DB_PATH']=str(Path(td)/'initial.db')
                db.init_db()
                self.assertEqual(db.all_customers(),[])
                self.assertEqual(db.all_reservations('2026-11-01','2026-12-01'),[])
            finally:
                if old is None:os.environ.pop('MYCARE_DB_PATH',None)
                else:os.environ['MYCARE_DB_PATH']=old
