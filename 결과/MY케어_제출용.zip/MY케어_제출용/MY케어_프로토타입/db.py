"""Local SQLite store for a single-operator prototype.
Do not expose this app to the public internet without authentication and encryption.
"""
from __future__ import annotations
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from datetime import datetime, date, timedelta
import os

BASE = Path(__file__).resolve().parent
CATEGORIES = ('caution', 'preference', 'rapport', 'visit')
PRIORITIES = ('HIGH', 'MEDIUM', 'LOW', 'UNKNOWN')


def location() -> Path:
    raw = os.environ.get('MYCARE_DB_PATH', 'data/mycare.db')
    path = Path(raw)
    if not path.is_absolute():
        path = BASE / path
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


@contextmanager
def connect():
    conn = sqlite3.connect(location(), timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    conn.execute('PRAGMA busy_timeout = 10000')
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    with connect() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS customers(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, phone TEXT NOT NULL DEFAULT '',
            category TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS reservations(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            external_id TEXT UNIQUE, customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL,
            title TEXT NOT NULL, service TEXT NOT NULL DEFAULT '',
            start_at TEXT NOT NULL, end_at TEXT NOT NULL DEFAULT '',
            source TEXT NOT NULL DEFAULT 'manual', status TEXT NOT NULL DEFAULT 'scheduled',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS notes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
            reservation_id INTEGER REFERENCES reservations(id) ON DELETE SET NULL,
            serviced_at TEXT NOT NULL, service TEXT NOT NULL DEFAULT '',
            memo TEXT NOT NULL, reviewed INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS facts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE CASCADE,
            note_id INTEGER NOT NULL REFERENCES notes(id) ON DELETE CASCADE,
            category TEXT NOT NULL CHECK(category IN ('caution','preference','rapport','visit')),
            statement TEXT NOT NULL, priority TEXT NOT NULL DEFAULT 'LOW'
            CHECK(priority IN ('HIGH','MEDIUM','LOW','UNKNOWN')),
            evidence TEXT NOT NULL DEFAULT '',
            source_type TEXT NOT NULL DEFAULT 'customer_report',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE INDEX IF NOT EXISTS ix_res_date ON reservations(start_at);
        CREATE INDEX IF NOT EXISTS ix_note_cust ON notes(customer_id);
        CREATE INDEX IF NOT EXISTS ix_fact_cust ON facts(customer_id);
        ''')


def all_customers(query=''):
    with connect() as c:
        if query:
            return [dict(x) for x in c.execute('SELECT * FROM customers WHERE name LIKE ? OR phone LIKE ? ORDER BY name,id', (f'%{query}%',f'%{query}%'))]
        return [dict(x) for x in c.execute('SELECT * FROM customers ORDER BY name,id')]


def get_customer(cid):
    with connect() as c:
        row = c.execute('SELECT * FROM customers WHERE id=?',(cid,)).fetchone()
        return dict(row) if row else None


def add_customer(name, phone='', category=''):
    if not name.strip(): raise ValueError('고객 이름을 입력하세요.')
    with connect() as c:
        return c.execute('INSERT INTO customers(name,phone,category) VALUES(?,?,?)',
                         (name.strip(),phone.strip(),category.strip())).lastrowid


def edit_customer(cid,name,phone='',category=''):
    if not name.strip(): raise ValueError('고객 이름을 입력하세요.')
    with connect() as c:
        c.execute('UPDATE customers SET name=?,phone=?,category=? WHERE id=?',
                  (name.strip(),phone.strip(),category.strip(),cid))


def delete_customer(cid):
    with connect() as c: c.execute('DELETE FROM customers WHERE id=?',(cid,))


def all_reservations(start_date=None,end_date=None):
    start_date = str(start_date or date.today()-timedelta(days=14))
    end_date = str(end_date or date.today()+timedelta(days=70))
    with connect() as c:
        return [dict(x) for x in c.execute('''
            SELECT r.*, c.name AS customer_name FROM reservations r
            LEFT JOIN customers c ON r.customer_id=c.id
            WHERE r.start_at >= ? AND r.start_at < ? AND r.status!='cancelled'
            ORDER BY r.start_at,r.id''',(start_date,end_date))]


def reservation(rid):
    with connect() as c:
        r=c.execute('SELECT * FROM reservations WHERE id=?',(rid,)).fetchone()
        return dict(r) if r else None


def add_reservation(title, when, cid=None, service='', source='manual', external_id=None, end_at=''):
    if not title.strip(): raise ValueError('예약 제목을 입력하세요.')
    with connect() as c:
        return c.execute('INSERT INTO reservations(title,start_at,customer_id,service,source,external_id,end_at) VALUES(?,?,?,?,?,?,?)',
                    (title.strip(),str(when),cid,service.strip(),source,external_id,end_at)).lastrowid


def link_reservation(rid,cid):
    with connect() as c: c.execute('UPDATE reservations SET customer_id=? WHERE id=?',(cid,rid))


def delete_reservation(rid):
    with connect() as c: c.execute('DELETE FROM reservations WHERE id=?',(rid,))


def upsert_google_events(events):
    count=0
    with connect() as c:
        for item in events:
            eid=item.get('id')
            title=item.get('summary','제목 없는 일정')
            start=item.get('start',{}).get('dateTime') or item.get('start',{}).get('date')
            end=item.get('end',{}).get('dateTime') or item.get('end',{}).get('date') or ''
            if not eid or not start: continue
            status=item.get('status','confirmed')
            c.execute('''INSERT INTO reservations(external_id,title,start_at,end_at,source,status)
              VALUES(?,?,?,?, 'google',?)
              ON CONFLICT(external_id) DO UPDATE SET title=excluded.title,start_at=excluded.start_at,
              end_at=excluded.end_at,status=excluded.status''',
              (eid,title,start,end,'cancelled' if status=='cancelled' else 'scheduled'))
            count+=1
    return count


def notes_for(cid):
    with connect() as c:
        return [dict(x) for x in c.execute('SELECT * FROM notes WHERE customer_id=? ORDER BY serviced_at DESC,id DESC',(cid,))]


def all_notes(limit=100):
    with connect() as c:
        return [dict(x) for x in c.execute('SELECT n.*, c.name customer_name FROM notes n JOIN customers c ON c.id=n.customer_id ORDER BY n.serviced_at DESC,n.id DESC LIMIT ?', (limit,))]


def get_note(nid):
    with connect() as c:
        r=c.execute('SELECT * FROM notes WHERE id=?',(nid,)).fetchone()
        return dict(r) if r else None


def add_note_with_facts(cid,memo,service,serviced_at,items,reservation_id=None):
    if not memo.strip(): raise ValueError('메모를 입력하세요.')
    with connect() as c:
        nid=c.execute('''INSERT INTO notes(customer_id,reservation_id,memo,service,serviced_at,reviewed)
           VALUES(?,?,?,?,?,1)''',(cid,reservation_id,memo.strip(),service.strip(),str(serviced_at))).lastrowid
        for item in items:
            if item.get('statement','').strip() and item.get('category') in CATEGORIES:
                c.execute('''INSERT INTO facts(customer_id,note_id,category,statement,priority,evidence,source_type)
                    VALUES(?,?,?,?,?,?,?)''',(
                      cid,nid,item['category'],item['statement'].strip(),
                      item.get('priority','LOW') if item.get('priority') in PRIORITIES else 'UNKNOWN',
                      item.get('evidence',''),item.get('source_type','unverified')))
        return nid


def edit_note(nid,memo,service,serviced_at):
    if not memo.strip(): raise ValueError('메모를 입력하세요.')
    with connect() as c:
        c.execute('UPDATE notes SET memo=?,service=?,serviced_at=? WHERE id=?',
                  (memo.strip(),service.strip(),str(serviced_at),nid))
        # Extracted facts may no longer match an edited source; discard pending prior facts.
        c.execute('DELETE FROM facts WHERE note_id=?',(nid,))


def replace_note_facts(nid,items):
    with connect() as c:
        source=c.execute('SELECT customer_id FROM notes WHERE id=?',(nid,)).fetchone()
        if not source: raise ValueError('원본 메모를 찾을 수 없습니다.')
        cid=source['customer_id']
        c.execute('DELETE FROM facts WHERE note_id=?',(nid,))
        for item in items:
            if item.get('statement','').strip() and item.get('category') in CATEGORIES:
                c.execute('''INSERT INTO facts(customer_id,note_id,category,statement,priority,evidence,source_type)
                VALUES(?,?,?,?,?,?,?)''',(cid,nid,item['category'],item['statement'].strip(),
                item.get('priority','LOW') if item.get('priority') in PRIORITIES else 'UNKNOWN',
                item.get('evidence',''),item.get('source_type','unverified')))


def delete_note(nid):
    with connect() as c: c.execute('DELETE FROM notes WHERE id=?',(nid,))


def facts_for(cid):
    with connect() as c:
        return [dict(x) for x in c.execute('''SELECT f.*, n.serviced_at, n.service, n.memo original_memo
           FROM facts f JOIN notes n ON n.id=f.note_id
           WHERE f.customer_id=? ORDER BY n.serviced_at DESC, f.id DESC''',(cid,))]


def edit_fact(fid,statement,category,priority,source_type=None):
    if category not in CATEGORIES or priority not in PRIORITIES: raise ValueError('잘못된 분류 값입니다.')
    if not statement.strip(): raise ValueError('내용을 입력하세요.')
    with connect() as c:
        if source_type is None:
            c.execute('UPDATE facts SET statement=?,category=?,priority=? WHERE id=?',
                      (statement.strip(),category,priority,fid))
        else:
            if source_type not in ('customer_report','owner_observation','unclear'):
                raise ValueError('잘못된 정보 출처입니다.')
            c.execute('UPDATE facts SET statement=?,category=?,priority=?,source_type=? WHERE id=?',
                      (statement.strip(),category,priority,source_type,fid))


def delete_fact(fid):
    with connect() as c: c.execute('DELETE FROM facts WHERE id=?',(fid,))


def seed_demo():
    with connect() as c:
        count=c.execute('SELECT COUNT(*) FROM customers').fetchone()[0]
        initialized=c.execute("SELECT value FROM meta WHERE key='demo_initialized'").fetchone()
        if count or initialized:return False
        c.execute("INSERT INTO meta(key,value) VALUES('demo_initialized','1')")
    demos=[
        ('김지연','', '피부관리'),('박수민','','속눈썹'),('이서윤','','네일'),
        ('최민호','','두피관리'),('김민지','','네일'),('정유진','','피부관리'),
        ('한지수','','왁싱'),('오서연','','속눈썹'),('이도윤','','두피관리'),('최하린','','네일')
    ]
    ids=[add_customer(*d) for d in demos]
    day=date.today()
    schedule=[(0,10,ids[0],'김지연 피부 관리','피부관리'),(0,12,ids[1],'박수민 속눈썹 연장','속눈썹'),
              (0,14,ids[2],'이서윤 네일','네일'),(0,16,ids[3],'최민호 두피 케어','두피관리'),
              (1,11,ids[4],'김민지 네일 예약','네일'),(1,15,ids[5],'정유진 피부 케어','피부관리')]
    for days,hour,cid,title,svc in schedule:
        add_reservation(title,datetime.combine(day+timedelta(days=days),datetime.min.time()).replace(hour=hour).isoformat(timespec='minutes'),cid,svc)
    def note(cidx, days_ago, service, memo, facts):
        add_note_with_facts(ids[cidx],memo,service,day-timedelta(days=days_ago),facts)
    def f(cat,text,priority='LOW'):
        return dict(category=cat,statement=text,priority=priority,source_type='customer_report')
    note(0,21,'피부관리','특정 화장품을 바른 뒤 붉어짐이 있었다고 함. 자극 적은 관리 원함. 다음 달 여행 예정.',
         [f('caution','특정 화장품 사용 뒤 붉어짐을 경험했다고 말함. 원인 미확인','HIGH'),f('preference','자극이 적은 관리 선호'),f('rapport','여행 계획을 언급함')])
    note(0,49,'피부관리','피부가 건조하다고 이야기함. 자연스러운 케어 선호.',
         [f('caution','건조함을 언급함','MEDIUM'),f('preference','자연스러운 케어 선호')])
    note(1,18,'속눈썹','접착제 사용 후 눈가가 따끔거렸다고 함. 너무 진한 연장은 원하지 않음.',
         [f('caution','접착제 사용 후 눈가 따끔거림 경험, 원인 미확인','HIGH'),f('preference','과하게 진한 스타일 비선호')])
    note(1,54,'속눈썹','자연스러운 컬이 마음에 든다고 했음.',[f('preference','자연스러운 컬 선호')])
    note(2,14,'네일','파스텔톤을 좋아하고 짧은 길이 선호. 다음 주 면접 예정.',
         [f('preference','파스텔톤과 짧은 길이 선호'),f('rapport','면접 예정이라고 말함')])
    note(3,23,'두피관리','시술 중 압력이 세면 불편하다고 했음. 운동을 즐긴다고 함.',
         [f('caution','강한 압력이 불편하다고 함','MEDIUM'),f('rapport','운동을 즐김')])
    note(4,24,'네일','젤 제거 후 손톱 주변이 가려웠다고 함. 베이지색 선호.',
         [f('caution','젤 제거 후 가려움 경험, 원인 미확인','HIGH'),f('preference','베이지색 선호')])
    note(4,62,'네일','핑크색을 선택함. 다음에는 다른 색을 해보고 싶다고 이야기함.',
         [f('preference','이전 방문에서 핑크색을 선택함')])
    note(5,19,'피부관리','시술 도중 향이 강한 제품을 불편해함.',[f('caution','향이 강한 제품에 불편함을 표현함','MEDIUM')])
    note(6,35,'왁싱','시술 후 붉어짐을 이야기함. 원인은 확인되지 않음.',[f('caution','시술 후 붉어짐 경험, 원인 미확인','HIGH')])
    note(7,45,'속눈썹','자연스러운 길이를 좋아함. 해외여행 예정.',[f('preference','자연스러운 길이 선호'),f('rapport','해외여행 계획 언급')])
    note(8,40,'두피관리','가벼운 마사지 선호.',[f('preference','가벼운 마사지 선호')])
    note(9,10,'네일','아트보다 단색을 선호한다고 말함.',[f('preference','단색 스타일 선호')])
    return True
