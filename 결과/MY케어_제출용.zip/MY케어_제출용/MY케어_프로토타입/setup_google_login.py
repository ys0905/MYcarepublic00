"""Configure optional Streamlit Google login with a Google OAuth *Web* client.
Runs locally, never uploads credentials. Restart Streamlit after running.
"""
from pathlib import Path
import json
from getpass import getpass
import os
import secrets

ROOT=Path(__file__).resolve().parent
REDIRECT='http://localhost:8501/oauth2callback'
print('MY케어 구글 로그인 설정 (Google OAuth 웹 애플리케이션 필요)')
print('Google Cloud 승인된 리디렉션 URI:', REDIRECT)
print('주의: 데스크톱용 credentials.json의 ID는 사용할 수 없습니다.')
print('비밀값을 화면에 표시하지 않고 .streamlit/secrets.toml 파일에 저장합니다.')
client_id=input('웹 클라이언트 ID: ').strip()
client_secret=getpass('웹 클라이언트 보안 비밀 (입력 숨김): ').strip()
if not client_id or not client_secret:
    print('입력값이 없어 취소했습니다.');raise SystemExit(1)
path=ROOT/'.streamlit'/'secrets.toml'
path.parent.mkdir(exist_ok=True)
if path.exists() and input('기존 로그인 설정을 덮어쓸까요? (y/N): ').lower()!='y':
    print('취소했습니다.');raise SystemExit(0)
data={'redirect_uri':REDIRECT,'cookie_secret':secrets.token_urlsafe(48),
      'client_id':client_id,'client_secret':client_secret,
      'server_metadata_url':'https://accounts.google.com/.well-known/openid-configuration'}
text='[auth]\n'+''.join(f'{k} = {json.dumps(v,ensure_ascii=False)}\n' for k,v in data.items())
path.write_text(text,encoding='utf-8')
try:os.chmod(path,0o600)
except OSError:pass
print('설정 완료. 실행 중인 MY케어 창을 종료한 다음 1-run-MYcare.bat를 다시 실행하세요.')
print('다른 구글 계정으로 로그인해도 DB는 아직 분리되지 않습니다. 공유 서버 배포 금지.')
