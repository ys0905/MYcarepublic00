@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel% equ 0 (py -m pip install -r requirements.txt) else (python -m pip install -r requirements.txt)
echo.
echo Installation finished. Press any key.
pause >nul
