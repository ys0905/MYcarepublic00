@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel% equ 0 (
  py setup_google_login.py
) else (
  python setup_google_login.py
)
echo.
pause
