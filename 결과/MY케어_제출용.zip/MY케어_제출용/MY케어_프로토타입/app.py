"""MY케어: one-person beauty shop customer memory / appointment briefing prototype.
Run locally with `python -m streamlit run app.py`.
"""
from __future__ import annotations
import html
import os
from datetime import date, datetime, timedelta
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv
import db
import services

ROOT=Path(__file__).resolve().parent
load_dotenv(ROOT/'.env')
st.set_page_config(page_title='MY케어 | 뷰티샵 고객 관리',page_icon='✳',layout='wide',initial_sidebar_state='expanded')
# Optional Google login (OIDC). Off until an OAuth Web client is configured.
# This is a local prototype: accounts do not have separate databases.
if services.google_login_configured():
    if not hasattr(st, 'login'):
        st.error('구글 로그인 기능을 사용하려면 0-install.bat로 Streamlit을 업데이트해 주세요.')
        st.stop()
    if not st.user.is_logged_in:
        st.title('MY케어')
        st.caption('뷰티샵 고객 기록 · 시술 전 AI 브리핑')
        st.write('이 프로그램을 이용하려면 Google 계정으로 로그인하세요.')
        st.button('Google 계정으로 로그인', on_click=st.login, type='primary')
        st.stop()
db.init_db()
# No automatic demo data. Customers and reservations start empty.


CSS='''
<style>
:root{--ink:#26272b;--muted:#888990;--line:#e8e8eb;--surface:#f8f8f9}
.stApp{background:#fff;color:var(--ink)}
#MainMenu,footer,[data-testid="stDecoration"]{visibility:hidden}
.block-container{padding-top:.7rem;padding-bottom:1.5rem;max-width:1490px;padding-left:1.7rem;padding-right:1.7rem}
section[data-testid="stSidebar"]{background:#fafafa;border-right:1px solid #eeeeef;min-width:220px!important}
section[data-testid="stSidebar"] div[data-testid="stVerticalBlock"]{gap:.48rem}
section[data-testid="stSidebar"] .stButton>button{border:0;border-radius:12px;box-shadow:none;text-align:left;justify-content:flex-start;padding:10px 14px;font-size:14px;font-weight:600;background:transparent;color:#38383c;width:100%;min-height:40px}
section[data-testid="stSidebar"] .stButton>button[kind="primary"]{background:#ebebee;color:#16161a;font-weight:750;border-left:3px solid #37373c}
section[data-testid="stSidebar"] .stButton>button:hover{background:#efeff1;color:#111}
.stButton>button[kind="primary"],.stFormSubmitButton>button[kind="primary"]{background:#333338;border:1px solid #333338;border-radius:10px;color:white;box-shadow:none}
.stButton>button[kind="primary"]:hover,.stFormSubmitButton>button[kind="primary"]:hover{background:#151519;border-color:#151519;color:white}
.stButton>button[kind="secondary"],.stFormSubmitButton>button[kind="secondary"]{border:1px solid #dedee3;border-radius:10px;background:#fff;color:#2c2c31;box-shadow:none}
.stButton>button{min-height:40px}
div[data-testid="stVerticalBlockBorderWrapper"]>div{border-radius:16px!important;border-color:var(--line)!important;box-shadow:none!important}
div[data-testid="stTextInput"] input,div[data-testid="stTextArea"] textarea,div[data-testid="stSelectbox"]>div{border-radius:10px!important}
[data-testid="stMetric"]{padding:12px;background:#f7f7f8;border:1px solid #eeeef0;border-radius:12px}
.sidebar-brand{padding:8px 6px 24px 6px;line-height:1.4}
.sidebar-brand .brand-title{display:flex;align-items:center;gap:9px}
.sidebar-brand .brand-name{font-size:23px;letter-spacing:-1.2px;font-weight:800;color:#242428}
.sidebar-brand .brand-subtitle{display:block;font-size:12px;color:#999aa2;margin-top:6px}
.sidebar-brand .sidebar-logo{display:inline-flex;flex:0 0 35px;align-items:center;justify-content:center;width:35px;height:35px;border-radius:11px;background:#35353a;color:#fff;font-size:16px}
.moa-sub{font-size:12px;color:#92929b;margin:2px 0 11px}
.moa-head{font-size:28px;font-weight:800;letter-spacing:-1px;margin:0 0 3px}
.moa-eyebrow{font-size:11px;letter-spacing:.4px;color:#888991;font-weight:650}
.moa-small{color:#85858c;font-size:12px}
.moa-customer{font-size:23px;font-weight:780;letter-spacing:-.7px;margin:0}
.moa-tag{background:#f0f0f2;border-radius:15px;color:#5a5a61;font-size:12px;padding:4px 8px;margin:0 3px;display:inline-block}
.moa-brief{border:1px solid #ededf0;background:#fff;padding:12px 14px;border-radius:11px;margin-bottom:8px;display:flex;gap:12px;align-items:flex-start;line-height:1.5}
.moa-brief>span:first-child{width:84px;flex-shrink:0;color:#51515a;font-weight:700;font-size:13px}
.moa-brief>span:last-child{font-size:13px;color:#323238;flex:1}
.moa-caution{background:#f7f7f8;border-color:#e9e9ec}
.moa-empty{border:1px dashed #e0e0e4;border-radius:12px;padding:18px;color:#96969e;font-size:13px;text-align:center}
.moa-foot{color:#9b9ba2;font-size:12px;padding-top:16px}
.st-key-reservations_panel div[data-testid="stVerticalBlock"]{gap:.45rem}
.st-key-reservations_panel .stButton>button{min-height:39px}
.st-key-dashboard_workspace div[data-testid="stVerticalBlock"]{gap:.65rem}
.st-key-dashboard_workspace div[data-testid="stRadio"]{padding:.15rem 0}
.st-key-dashboard_workspace div[data-testid="stRadio"]>div{gap:1.4rem}
.st-key-dashboard_workspace div[data-testid="stTextArea"] textarea{min-height:115px}
</style>
'''
st.markdown(CSS,unsafe_allow_html=True)


def safe(x):return html.escape(str(x if x is not None else ''))
def short_date(x):
    if not x:return '-'
    try: return datetime.fromisoformat(x.replace('Z','+00:00')).strftime('%m.%d')
    except (ValueError,AttributeError): return str(x)[:10]
def hour(x):
    if not x:return '--:--'
    try:
        return datetime.fromisoformat(x.replace('Z','+00:00')).astimezone().strftime('%H:%M') if ('+' in x[10:] or 'Z' in x) else datetime.fromisoformat(x).strftime('%H:%M')
    except (ValueError,AttributeError):return str(x)[11:16]
def day_str(x):
    try: return datetime.fromisoformat(x.replace('Z','+00:00')).date().isoformat()
    except (ValueError,AttributeError): return str(x)[:10]
def rerun():st.rerun()
def show_dashboard_memo():st.session_state.dashboard_view='시술 메모'
def navigate(page, customer=None):
    st.session_state.page=page
    if customer is not None: st.session_state.cid=customer
    rerun()
def customers_by_id():return {c['id']:c for c in db.all_customers()}

for key,default in [('page','오늘의 예약'),('chosen_date',date.today()),('cid',None),('rid',None),('pending',None),('dashboard_view','AI 브리핑')]:
    if key not in st.session_state: st.session_state[key]=default

with st.sidebar:
    st.markdown('<div class="sidebar-brand"><div class="brand-title"><span class="sidebar-logo">✳</span><strong class="brand-name">MY케어</strong></div><span class="brand-subtitle">MY케어 · 뷰티샵 고객 관리</span></div>',unsafe_allow_html=True)
    for label in ['오늘의 예약','고객 목록','시술 기록','설정']:
        if st.button(label,key=f'nav_{label}',type='primary' if st.session_state.page==label else 'secondary',use_container_width=True):
            st.session_state.page=label;st.session_state.pending=None;rerun()
    st.write('')
    st.caption('시연용 로컬 프로토타입')
    if services.google_login_configured():
        st.caption('Google 로그인: ' + str(st.user.get('email', '인증됨')))
        if st.button('로그아웃',key='google_logout',use_container_width=True):
            st.logout()
    else:
        st.caption('Google 로그인 미설정 · 로컬 모드')
    st.caption('네일 · 속눈썹 · 피부관리 · 기타 뷰티업')


def label_row(title,subtitle=''):
    st.markdown(f'<div class="moa-head">{safe(title)}</div><div class="moa-sub">{safe(subtitle)}</div>',unsafe_allow_html=True)


def facts_markup(cid):
    facts=db.facts_for(cid)
    groups=[('caution','시술 주의사항'),('preference','고객 취향'),('rapport','라포 정보'),('visit','이전 시술')]
    if not facts:
        st.markdown('<div class="moa-empty">저장된 정보가 없어요. 시술 메모를 남겨 보세요.</div>',unsafe_allow_html=True)
        return
    for cat,title in groups:
        entries=[f for f in facts if f['category']==cat]
        dedup=[]; seen=set()
        for f in entries:
            text=f['statement'].strip()
            if text in seen:continue
            seen.add(text);dedup.append(f)
        if not dedup:continue
        vals=[]
        for f in dedup[:2]:
            old=(date.today()-date.fromisoformat(day_str(f['serviced_at']))).days>60 if f['serviced_at'] else False
            suffix=' · 과거 기록 확인' if old else ''
            tag=' · 우선 확인' if cat=='caution' and f['priority']=='HIGH' else ''
            vals.append(f'<div>{safe(f["statement"])}<span class="moa-small">{safe(tag+suffix)}</span></div>')
        custom=' moa-caution' if cat=='caution' else ''
        st.markdown(f'<div class="moa-brief{custom}"><span>{title}</span><span>{"".join(vals)}</span></div>',unsafe_allow_html=True)
    st.caption('원장님이 저장한 메모를 바탕으로 표시합니다. 시술 가능 여부나 알레르기를 AI가 진단하지 않습니다.')


def review_pending():
    p=st.session_state.get('pending')
    if not p:return
    st.divider()
    mode=p['mode']
    st.markdown('#### 분석 내용 확인')
    st.caption(('Gemini 실제 분석 · 사용 모델: ' + p.get('model','확인 안 됨')) if mode=='gemini' else '체험용 규칙 분석 · Gemini API 연결 전에는 실제 AI가 아닙니다.')
    st.info('원본 메모와 비교하고 잘못된 정보는 수정하거나 체크를 해제하세요. 확인한 정보만 저장됩니다.')
    options={'caution':'시술 주의사항','preference':'고객 취향','rapport':'라포 정보','visit':'방문·시술 이력'}
    catkeys=list(options)
    levels=['HIGH','MEDIUM','LOW','UNKNOWN']
    source_labels={'customer_report':'고객이 말한 내용','owner_observation':'원장이 관찰한 내용','unclear':'출처·의미 미확인'}
    with st.form('review_pending_form'):
        edited=[]
        if not p['items']:st.caption('추출된 정보가 없습니다. 메모 자체는 저장할 수 있습니다.')
        for i,item in enumerate(p['items']):
            with st.container(border=True):
                yes=st.checkbox('이 정보 저장',value=True,key=f'rv_ok_{i}_{p["nonce"]}')
                desc=st.text_input('추출 내용',value=item['statement'],key=f'rv_text_{i}_{p["nonce"]}')
                a,b,c=st.columns(3)
                with a: cat=st.selectbox('분류',catkeys,index=catkeys.index(item['category']),format_func=lambda s:options[s],key=f'rv_cat_{i}_{p["nonce"]}')
                with b: prior=st.selectbox('확인 우선순위',levels,index=levels.index(item.get('priority','LOW')),key=f'rv_prior_{i}_{p["nonce"]}')
                source_ids=list(source_labels)
                with c: source=st.selectbox('정보 출처',source_ids,index=source_ids.index(item.get('source_type','unclear')),format_func=lambda k:source_labels[k],key=f'rv_source_{i}_{p["nonce"]}')
                st.caption('근거: '+item.get('evidence','(원문 확인 필요)'))
                if yes and desc.strip():edited.append({**item,'statement':desc.strip(),'category':cat,'priority':prior,'source_type':source})
        submitted=st.form_submit_button('검토 완료 · 고객 기록에 저장',type='primary',use_container_width=True)
    if submitted:
        if p.get('edit_note_id'):
            db.replace_note_facts(p['edit_note_id'],edited)
        else:
            db.add_note_with_facts(p['cid'],p['memo'],p['service'],p['serviced_at'],edited,p.get('rid'))
        st.session_state.pending=None
        st.success('고객 기록에 저장했습니다.')
        rerun()
    if st.button('분석 취소',key='cancel_review'):
        st.session_state.pending=None;rerun()


def run_analysis(memo,service,cid,serviced_at,reservation_id=None,edit_note_id=None):
    if not memo.strip():
        st.warning('시술 메모를 입력해 주세요.');return
    with st.spinner('메모를 분석하고 있어요...'):
        try:
            key=os.getenv('GEMINI_API_KEY','').strip()
            if key:
                items,used_model=services.analyze_with_gemini(memo,service,return_model=True)
                mode='gemini'
            else:
                items=services.local_demo_extract(memo,service)
                mode='local';used_model=''
        except services.GeminiBusyError as e:
            st.warning(str(e))
            st.caption('메모는 아직 저장되지 않았어요. 작성한 내용을 그대로 두고 다시 분석할 수 있어요.')
            return
        except Exception as e:
            code=services._gemini_error_code(e)
            if code==429:
                st.error('Gemini API 사용량 제한(429)이에요. Google AI Studio의 프로젝트 사용량과 한도를 확인해 주세요.')
            elif code in (401,403):
                st.error('Gemini API 키 또는 프로젝트 권한을 확인해 주세요. (401/403)')
            elif code==404:
                st.error('선택된 Gemini 모델을 사용할 수 없어요. 설정에서 모델을 변경해 주세요. (404)')
            else:
                st.error('Gemini 분석 중 오류가 발생했어요. 아래 메시지를 확인해 주세요.')
            st.caption(str(e)[:280]);return
    st.session_state.pending=dict(cid=cid,rid=reservation_id,memo=memo,service=service,
        serviced_at=serviced_at,items=items,mode=mode,model=used_model,edit_note_id=edit_note_id,nonce=datetime.now().timestamp())
    rerun()


def memo_editor(cid,reservation_id=None,key_prefix='memo'):
    if not cid:return
    if st.session_state.get('pending') and st.session_state.pending['cid']==cid:
        review_pending()
        return
    st.markdown('#### 시술 메모 작성')
    st.caption('시술 내용과 고객의 특이사항을 자유롭게 적어 주세요. 개인정보는 최소한으로 기록하세요.')
    with st.form(f'{key_prefix}_{cid}_{reservation_id}'):
        service=st.text_input('시술 종류 (선택)',value='',placeholder='예: 피부관리, 속눈썹, 네일, 왁싱')
        when=st.date_input('시술 날짜',value=date.today())
        memo=st.text_area('시술 메모',height=135,max_chars=1500,
            placeholder='예: 오늘 관리 진행. 지난번 특정 제품 사용 후 붉어짐이 있었다고 하심. 자연스러운 스타일 선호.')
        create=st.form_submit_button('메모 분석하기',use_container_width=True,type='primary')
    if create:
        run_analysis(memo,service,cid,when,reservation_id=reservation_id)


def sync_google():
    with st.spinner('구글 캘린더 일정을 불러오고 있습니다...'):
        try:
            rows=services.google_events()
            count=db.upsert_google_events(rows)
            st.success(f'캘린더 일정 {count}건을 불러왔습니다. 신규 일정은 고객 연결을 확인해 주세요.')
        except Exception as e:
            st.error('구글 캘린더 연동 실패: '+str(e)[:270])


def shift_dashboard_date(days: int):
    """Move the date in a callback, before Streamlit renders its date widget."""
    new_date=st.session_state.chosen_date+timedelta(days=days)
    st.session_state.chosen_date=new_date
    st.session_state.selected_day=new_date


def update_dashboard_date():
    """Sync the date input's chosen value to the dashboard."""
    st.session_state.chosen_date=st.session_state.selected_day


def date_picker_bar():
    if 'selected_day' not in st.session_state:
        st.session_state.selected_day=st.session_state.chosen_date
    left,mid,right,spacer,button=st.columns([.6,2.6,.6,3,2.1],vertical_alignment='center')
    with left:
        st.button('‹',key='prev_date',use_container_width=True,
                  on_click=shift_dashboard_date,args=(-1,))
    with mid:
        st.date_input('조회 날짜',label_visibility='collapsed',key='selected_day',
                      on_change=update_dashboard_date)
    with right:
        st.button('›',key='next_date',use_container_width=True,
                  on_click=shift_dashboard_date,args=(1,))
    with button:
        if st.button('Google Calendar 동기화',use_container_width=True,key='cal_top'):
            sync_google();rerun()


def booking_card(r):
    selected=r['id']==st.session_state.rid
    title=f'{hour(r["start_at"])}    {r["customer_name"] or r["title"]}'
    return st.button(title,use_container_width=True,type='primary' if selected else 'secondary',key=f'booking_{r["id"]}')


def dashboard():
    label_row('오늘의 예약','예약을 선택해 브리핑을 확인하거나 시술 기록을 남겨 보세요.')
    date_picker_bar()
    chosen=st.session_state.chosen_date.isoformat()
    rs=[r for r in db.all_reservations(chosen,(st.session_state.chosen_date+timedelta(days=1)).isoformat())
        if day_str(r['start_at'])==chosen]
    if rs and st.session_state.rid not in [r['id'] for r in rs]:st.session_state.rid=rs[0]['id']
    col_left,col_right=st.columns([.88,2.7],gap='medium')
    with col_left:
        with st.container(border=True,key='reservations_panel'):
            st.markdown(f'#### 예약 일정  ·  {len(rs)}건')
            st.caption(st.session_state.chosen_date.strftime('%Y년 %m월 %d일'))
            if not rs:st.info('선택한 날짜에 일정이 없습니다.')
            for r in rs:
                if booking_card(r):
                    st.session_state.rid=r['id'];st.session_state.pending=None;st.session_state.dashboard_view='AI 브리핑';rerun()
        with st.expander('예약 직접 추가'):
            with st.form('add_res_dashboard'):
                customers=db.all_customers(); options=[None]+[c['id'] for c in customers]
                name_map={c['id']:c['name']+f' (#{c["id"]})' for c in customers}
                name_map[None]='고객 미연결'
                title=st.text_input('예약 제목',placeholder='예: 김지연 피부관리')
                cid=st.selectbox('고객',options,format_func=lambda v:name_map.get(v,''))
                svc=st.text_input('시술 종류')
                time=st.time_input('시간',value=datetime.now().replace(minute=0,second=0).time())
                if st.form_submit_button('예약 추가',use_container_width=True):
                    if title.strip():
                        db.add_reservation(title,datetime.combine(st.session_state.chosen_date,time).isoformat(timespec='minutes'),cid,svc)
                        rerun()
                    else:st.warning('예약 제목을 입력해 주세요.')
    with col_right:
        if not rs:
            with st.container(border=True):
                st.subheader('예약이 아직 없어요')
                st.write('Google Calendar를 동기화하거나 왼쪽에서 예약을 추가하세요.')
            return
        chosen_booking=next(r for r in rs if r['id']==st.session_state.rid)
        cid=chosen_booking['customer_id']
        with st.container(border=True,key='dashboard_workspace'):
            x,y=st.columns([3.3,1.2],vertical_alignment='center')
            with x:
                if cid:
                    c=db.get_customer(cid)
                    st.markdown(f'<div class="moa-eyebrow">{safe(chosen_booking["service"] or "고객 예약")}</div><div class="moa-customer">{safe(c["name"])}</div><div class="moa-small">{hour(chosen_booking["start_at"])} 예약 · 고객 #{cid}</div>',unsafe_allow_html=True)
                else:
                    st.markdown(f'<div class="moa-eyebrow">고객 연결 필요</div><div class="moa-customer">{safe(chosen_booking["title"])}</div>',unsafe_allow_html=True)
            with y:
                if cid and st.button('고객 정보 보기',key='dashboard_customer',use_container_width=True):
                    navigate('고객 목록',cid)
            if cid:
                view=st.radio('현재 화면',['AI 브리핑','시술 메모'],key='dashboard_view',horizontal=True,label_visibility='collapsed')
                if view=='AI 브리핑':
                    st.markdown('#### AI 맞춤 브리핑')
                    facts_markup(cid)
                    st.button('＋  이 고객의 시술 메모 작성',key='goto_memo',use_container_width=True,on_click=show_dashboard_memo)
                else:
                    memo_editor(cid,chosen_booking['id'],'dashboard_note')
            else:
                st.warning('캘린더 일정 제목만으로 고객을 자동 확정하지 않습니다. 연결할 고객을 직접 선택해 주세요.')
                customers=db.all_customers();mp={x['id']:f'{x["name"]} · #{x["id"]}' for x in customers}
                candidate=st.selectbox('연결할 고객', [None]+list(mp),format_func=lambda x:'선택하세요' if x is None else mp[x],key=f'link_{chosen_booking["id"]}')
                if st.button('이 예약에 고객 연결',disabled=candidate is None):
                    db.link_reservation(chosen_booking['id'],candidate);rerun()
                if st.button('신규 고객 등록',key='make_from_res'):navigate('고객 목록')


def customer_details(cid):
    c=db.get_customer(cid)
    if not c:return
    st.markdown(f'<div class="moa-customer">{safe(c["name"])}</div><div class="moa-small">고객 번호 #{cid} · {safe(c["category"] or "업종 미지정")}</div>',unsafe_allow_html=True)
    st.write('')
    col1,col2=st.columns([1.5,1.6],gap='medium')
    with col1:
        with st.container(border=True):
            st.markdown('#### 고객 정보')
            st.write('연락처: '+(c['phone'] or '미등록'))
            st.write('업종: '+(c['category'] or '미지정'))
            with st.expander('고객 정보 수정'):
                with st.form('edit_cust_'+str(cid)):
                    newname=st.text_input('이름',value=c['name']);newphone=st.text_input('연락처',value=c['phone']);newcat=st.text_input('업종',value=c['category'])
                    if st.form_submit_button('변경 저장'):
                        try:db.edit_customer(cid,newname,newphone,newcat);rerun()
                        except ValueError as e:st.warning(str(e))
            with st.expander('고객 삭제'):
                st.warning('고객 삭제 시 모든 방문 메모와 추출 정보가 함께 삭제됩니다. 예약에는 연결이 해제됩니다.')
                with st.form('delete_cust_'+str(cid)):
                    confirm=st.checkbox('삭제를 확인했습니다.')
                    if st.form_submit_button('고객 영구 삭제',disabled=not confirm):
                        db.delete_customer(cid);st.session_state.cid=None;rerun()
        with st.container(border=True):
            st.markdown('#### 이전 메모')
            notes=db.notes_for(cid)
            if not notes:st.caption('아직 기록이 없습니다.')
            for n in notes[:15]:
                with st.expander(f'{short_date(n["serviced_at"])} · {n["service"] or "시술 기록"}'):
                    st.write(n['memo'])
                    st.caption('기록 변경은 아래 시술 기록 화면에서 가능합니다.')
    with col2:
        with st.container(border=True):
            st.markdown('#### 고객별 브리핑')
            facts_markup(cid)
        with st.container(border=True):
            memo_editor(cid,None,'customer_note')


def customers_page():
    label_row('고객 목록','고객별 취향, 시술 기록과 주의사항을 관리합니다.')
    with st.expander('새 고객 등록'):
        with st.form('new_customer'):
            a,b,c=st.columns(3)
            with a:name=st.text_input('고객 이름')
            with b:phone=st.text_input('연락처 (선택)')
            with c:cat=st.selectbox('업종', ['','네일','속눈썹','피부관리','왁싱','두피관리','기타'])
            if st.form_submit_button('고객 등록',type='primary'):
                try:st.session_state.cid=db.add_customer(name,phone,cat);rerun()
                except ValueError as e:st.warning(str(e))
    search=st.text_input('고객 검색',placeholder='이름 또는 연락처로 검색',label_visibility='collapsed')
    people=db.all_customers(search)
    if not people:st.info('검색 결과가 없습니다.');return
    option_ids=[c['id'] for c in people]
    if st.session_state.cid not in option_ids:st.session_state.cid=option_ids[0]
    opts={c['id']:f'{c["name"]} · #{c["id"]} · {c["category"] or "미지정"}' for c in people}
    selected=st.selectbox('고객 선택',option_ids,index=option_ids.index(st.session_state.cid),format_func=lambda x:opts[x])
    if selected!=st.session_state.cid:st.session_state.cid=selected;st.session_state.pending=None
    customer_details(st.session_state.cid)


def records_page():
    label_row('시술 기록','원본 메모와 AI 추출 결과를 확인하고 수정합니다.')
    notes=db.all_notes()
    if not notes:st.info('저장된 메모가 없습니다.');return
    note_options={n['id']:f'{short_date(n["serviced_at"])} · {n["customer_name"]} · {n["service"] or "메모"}' for n in notes}
    nid=st.selectbox('기록 선택',list(note_options),format_func=lambda i:note_options[i])
    n=db.get_note(nid)
    if n is None:return
    with st.container(border=True):
        st.markdown('#### 원본 시술 메모')
        with st.form('edit_note_'+str(nid)):
            serviced_at=st.date_input('시술 날짜',value=date.fromisoformat(day_str(n['serviced_at'])))
            svc=st.text_input('시술 종류',value=n['service'])
            memo=st.text_area('내용',value=n['memo'],height=140)
            if st.form_submit_button('메모 수정 저장'):
                try:
                    db.edit_note(nid,memo,svc,serviced_at)
                    st.info('원문이 바뀌어 이전 분류를 삭제했습니다. 아래 버튼에서 이 메모를 재분석할 수 있습니다.')
                    rerun()
                except ValueError as e: st.warning(str(e))
        if st.button('이 기록 다시 분석하기',key=f'reanalyze_{nid}',use_container_width=True):
            run_analysis(n['memo'],n['service'],n['customer_id'],n['serviced_at'],edit_note_id=nid)
        if st.session_state.get('pending') and st.session_state.pending.get('edit_note_id')==nid:
            review_pending()
        with st.expander('이 메모 삭제'):
            with st.form('delete_note_'+str(nid)):
                ok=st.checkbox('메모와 연결된 추출 정보도 삭제됨을 확인했습니다.')
                if st.form_submit_button('기록 삭제',disabled=not ok):db.delete_note(nid);rerun()
    facts=[f for f in db.facts_for(n['customer_id']) if f['note_id']==nid]
    st.markdown('#### 분류된 정보')
    if not facts:st.caption('이 기록에 추출된 정보가 없습니다.')
    readable={'caution':'주의사항','preference':'취향','rapport':'라포','visit':'시술 이력'}
    for f in facts:
        with st.expander(f'{readable[f["category"]]} · {f["statement"][:44]}'):
            st.caption('출처: '+(f['evidence'] or '원문 확인 필요')+' · '+f['source_type'])
            with st.form('fact_form_'+str(f['id'])):
                text=st.text_input('내용',value=f['statement'])
                a,b=st.columns(2)
                with a:cat=st.selectbox('구분',list(readable),index=list(readable).index(f['category']),format_func=lambda k:readable[k])
                with b:pri=st.selectbox('확인 우선순위',list(db.PRIORITIES),index=list(db.PRIORITIES).index(f['priority']))
                source_labels={'customer_report':'고객 진술','owner_observation':'원장 관찰','unclear':'미확인'}
                sources=list(source_labels)
                source_now=f['source_type'] if f['source_type'] in sources else 'unclear'
                src=st.selectbox('정보 출처',sources,index=sources.index(source_now),format_func=lambda v:source_labels[v])
                action=st.radio('처리',['수정 저장','항목 삭제'],horizontal=True)
                if st.form_submit_button('적용'):
                    if action=='항목 삭제':db.delete_fact(f['id'])
                    else:
                        try:db.edit_fact(f['id'],text,cat,pri,src)
                        except ValueError as e:st.warning(str(e));return
                    rerun()


def settings_page():
    label_row('설정','Google Calendar · Gemini API · 로그인 설정')
    with st.container(border=True):
        st.markdown('#### Gemini API 연결')
        current_model=os.getenv('GEMINI_MODEL', services.DEFAULT_GEMINI_MODEL)
        has_key=bool(os.environ.get('GEMINI_API_KEY','').strip())
        st.write('연결 상태: ' + ('API 키 저장됨 (실제 호출은 연결 테스트로 확인)' if has_key else 'API 키 미등록'))
        st.caption('기존 API 키가 저장되어 있다면, 키를 다시 입력하지 않고 모델만 변경할 수 있어요.')
        st.caption('실제 메모 분석 중 서버 오류(503)가 나면 자동 재시도하고, 필요하면 더 가벼운 대체 Gemini 모델로 분석합니다.')
        models=list(services.SUPPORTED_GEMINI_MODELS)
        if current_model not in models:models.append(current_model)
        suggested_model = services.DEFAULT_GEMINI_MODEL if current_model.startswith('gemini-2.') else current_model
        if current_model.startswith('gemini-2.'):
            st.warning('기존 Gemini 2.x 모델은 신규 프로젝트에서 지원되지 않을 수 있어요. 모델을 최신 버전으로 바꾼 후 저장하세요.')
        with st.form('gemini_api_settings',clear_on_submit=False):
            new_key=st.text_input('Gemini API 키 입력',type='password',placeholder='이미 키를 저장했다면 비워 두세요')
            model=st.selectbox('모델',models,index=models.index(suggested_model))
            saved=st.form_submit_button('Gemini 설정 저장',type='primary',use_container_width=True)
        if saved:
            try:
                final_key = new_key.strip() or os.environ.get('GEMINI_API_KEY','').strip()
                if not final_key:
                    st.warning('API 키를 입력해 주세요.')
                else:
                    services.save_gemini_settings(final_key, model)
                    st.success(f'Gemini 모델을 {model}(으)로 저장했어요. 아래 연결 테스트를 눌러 주세요.')
                    st.rerun()
            except ValueError as e:st.error(str(e))
        x,y=st.columns(2)
        with x:
            if st.button('Gemini 연결 테스트',disabled=not has_key,use_container_width=True):
                with st.spinner('Gemini API를 확인하고 있어요...'):
                    try:
                        services.test_gemini_connection()
                        st.success('Gemini API 응답을 확인했어요.')
                    except Exception as e:
                        message=str(e)
                        if 'no longer available' in message or 'is not found for API version' in message:
                            st.error('선택한 Gemini 모델을 사용할 수 없어요. 위에서 gemini-3.8-flash 또는 gemini-3.5-flash-lite를 선택하고 설정을 저장하세요.')
                        elif '401' in message or 'API key not valid' in message:
                            st.error('API 키 인증에 실패했어요. 저장된 키와 Google AI Studio의 키 제한 설정을 확인하세요.')
                        else:
                            if services._gemini_error_code(e)==503:
                                st.warning('API 키가 잘못된 것은 아니에요. 선택한 모델 서버가 혼잡합니다(503). 잠시 후 재시도하거나 다른 모델을 선택하세요.')
                            else:
                                st.error('Gemini 연결에 실패했어요. 모델·사용량·인터넷 연결을 확인하세요.')
                        st.caption(message[:360])
        with y:
            if st.button('저장된 Gemini 키 삭제',disabled=not has_key,use_container_width=True):
                services.clear_gemini_settings()
                st.success('저장된 키를 삭제했어요.')
                st.rerun()
        st.caption('키가 없을 때는 체험용 규칙 분석만 작동하며 실제 AI 분석이 아닙니다. API 키는 GitHub나 채팅에 올리지 마세요.')
    with st.container(border=True):
        st.markdown('#### Google Calendar')
        credential,token=services.credentials_status()
        st.write('캘린더 인증 정보: '+('설정됨' if credential else '미설정'))
        st.write('이 PC 캘린더 권한: '+('토큰 있음' if token else '아직 인증하지 않음'))
        st.caption('기존 프로젝트의 credentials.json을 이 앱 폴더로 복사하면 됩니다. 본인 PC의 token.json은 다른 사람과 공유하지 마세요.')
        if st.button('캘린더 일정 동기화',key='settings_sync',type='primary'):sync_google()
        st.caption('일정 제목만으로 고객을 임의로 추측하지 않으며, 예약별로 고객을 직접 연결해 주세요.')
    with st.container(border=True):
        st.markdown('#### Google 로그인 (IDP) · 선택 기능')
        st.write('로그인 상태: '+('Google 로그인 사용 중' if services.google_login_configured() else '미설정 (로컬 시연 모드)'))
        st.caption('캘린더 OAuth의 데스크톱용 credentials.json과는 별도입니다. Google Cloud에서 웹 애플리케이션 OAuth 클라이언트를 발급해야 합니다.')
        st.code('http://localhost:8501/oauth2callback',language='text')
        st.caption('Google Cloud의 승인된 리디렉션 URI에 위 주소를 등록하고, 2-google-login-setup.bat를 실행해 웹 클라이언트 ID와 보안 비밀을 설정한 뒤 앱을 재시작하세요.')
        st.warning('구글 로그인을 추가하더라도 이 버전은 계정별 DB 분리가 없습니다. 서로 다른 사용자에게 같은 고객 데이터가 보일 수 있으므로 공유 서버에 배포하면 안 됩니다.')
    with st.container(border=True):
        st.markdown('#### 데이터 및 배포')
        st.write('SQLite DB: `data/mycare.db` (처음 시작할 때 비어 있음)')
        st.caption('이 프로토타입은 로컬 테스트 전용입니다. 실제 고객 개인정보 대신 가상 데이터를 직접 입력해 사용해 주세요.')
        st.caption('공유용 파일에는 .env, .streamlit/secrets.toml, credentials.json, token.json, data/ 폴더를 넣지 마세요.')

page=st.session_state.page
if page=='오늘의 예약':dashboard()
elif page=='고객 목록':customers_page()
elif page=='시술 기록':records_page()
else:settings_page()
st.markdown('<div class="moa-foot">MY케어 · 1인 뷰티샵을 위한 고객 기록 및 시술 전 브리핑 · 가상 데이터로 시연 권장</div>',unsafe_allow_html=True)
